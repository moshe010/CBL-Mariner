
# NAME

mstmread

# SYNOPSiS

mstmread \<device\> \<addr\>

# DESCRIPTION

# SEE ALSO

The full documentation for **mstmread** is maintained as a Texinfo
manual. If the **info** and **mstmread** programs are properly installed
at your site, the command

> **info mstmread**

should give you access to the complete manual.
