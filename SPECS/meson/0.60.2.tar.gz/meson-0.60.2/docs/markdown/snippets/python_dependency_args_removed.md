## The Python Modules dependency method no longer accepts positional arguments

Previously these were igrnoed with a warning, now they're a hard error.
