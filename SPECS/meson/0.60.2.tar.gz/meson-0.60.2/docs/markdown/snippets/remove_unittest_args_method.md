## Compiler.unittest_args has been removed

It's never been documented, and it's been marked deprecated for a long time, so
let's remove it.
