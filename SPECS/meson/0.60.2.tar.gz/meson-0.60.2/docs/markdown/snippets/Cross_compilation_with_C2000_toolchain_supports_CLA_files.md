## Added support for CLA sources when cross-compiling with the C2000 toolchain

Support for CLA sources has been added for cross-compilation with the C2000 toolchain.
