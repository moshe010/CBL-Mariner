## Improvements for the Rustc compiler

- Werror now works, this set's `-D warnings`, which will cause rustc to error
  for every warning not explicitly disabled
- warning levels have been implemented
- support for meson's pic has been enabled
