## Waf support in external-project module

If the first argument is `'waf'`, special treatment is done for the
[waf](https://waf.io/) build system. The waf executable must be
found either in the current directory, or in system `PATH`.
