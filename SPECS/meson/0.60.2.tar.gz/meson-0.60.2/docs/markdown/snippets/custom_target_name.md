## Optional `custom_target()` name

The name argument is now optional and defaults to the basename of the first
output.