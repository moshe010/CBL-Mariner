## Installation tags

It is now possible to install only a subset of the installable files using
`meson install --tags tag1,tag2` command line.

See [documentation](Installing.md#installation-tags) for more details.
