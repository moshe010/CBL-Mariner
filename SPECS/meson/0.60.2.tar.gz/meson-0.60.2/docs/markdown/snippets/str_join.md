## Relax restrictions of `str.join()`

Since 0.60.0, the [[str.join]] method can take an arbitrary number of arguments
instead of just one list. Additionally, all lists past to [[str.join]] will now
be flattened.
