# Qt6 module

*New in Meson 0.57.0*

The Qt5 module provides tools to automatically deal with the various
tools and steps required for Qt.

{{ _include_qt_base.md }}
