---
short-description: User manual for Meson
...

# Manual

This is the user manual for Meson. It currently tracks the state of
Git head. If you are using an older version, some of the information
here might not work for you.
