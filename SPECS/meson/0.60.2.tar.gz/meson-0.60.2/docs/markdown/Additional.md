---
short-description: Misc documentation
...

# Additional documentation

This section references documents miscellaneous design, benchmarks, or
basically anything concerning Meson.
